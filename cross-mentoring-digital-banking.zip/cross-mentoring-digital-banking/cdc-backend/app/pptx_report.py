"""
Générateur du rapport exécutif PowerPoint (python-pptx), échelle 8 niveaux.
Construit UNIQUEMENT à partir d'agrégats — aucun score individuel (firewall).
build_report(agg) -> BytesIO prêt à streamer.
"""
from io import BytesIO
from datetime import date
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION

INK = RGBColor(0x12, 0x26, 0x3A)
INK2 = RGBColor(0x1E, 0x3A, 0x52)
ACCENT = RGBColor(0x0E, 0x7C, 0x6B)
GOLD = RGBColor(0xC0, 0x8A, 0x2D)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT = RGBColor(0xE2, 0xE8, 0xF0)
LIGHTBG = RGBColor(0xF4, 0xF6, 0xF8)
SLATE = RGBColor(0x33, 0x41, 0x55)
MUTE = RGBColor(0x64, 0x74, 0x8B)
ICE = RGBColor(0xCA, 0xDC, 0xFC)
HFONT, BFONT = "Cambria", "Calibri"
W, H = Inches(13.333), Inches(7.5)


def _text(slide, x, y, w, h, runs, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, wrap=True, space=1.0):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = wrap
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    if isinstance(runs, str):
        runs = [(runs, {})]
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = space
    for txt, o in runs:
        r = p.add_run()
        r.text = txt
        r.font.name = o.get("font", BFONT)
        r.font.size = Pt(o.get("size", 14))
        r.font.bold = o.get("bold", False)
        r.font.italic = o.get("italic", False)
        r.font.color.rgb = o.get("color", SLATE)
    return tb


def _card(slide, x, y, w, h, fill=WHITE, line=LIGHT):
    sp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h)
    sp.adjustments[0] = 0.06
    sp.fill.solid(); sp.fill.fore_color.rgb = fill
    if line is None:
        sp.line.fill.background()
    else:
        sp.line.color.rgb = line; sp.line.width = Pt(0.75)
    sp.shadow.inherit = False
    return sp


def _stat(slide, x, y, w, h, value, label, color=INK, sub=None):
    _card(slide, x, y, w, h)
    _text(slide, x + Inches(0.15), y + Inches(0.12), w - Inches(0.3), Inches(0.7),
          [(value, {"font": HFONT, "size": 30, "bold": True, "color": color})])
    _text(slide, x + Inches(0.16), y + h - Inches(0.72), w - Inches(0.32), Inches(0.4),
          [(label, {"size": 11, "color": SLATE})])
    if sub:
        _text(slide, x + Inches(0.16), y + h - Inches(0.36), w - Inches(0.32), Inches(0.3),
              [(sub, {"size": 9, "italic": True, "color": MUTE})])


def _title(slide, kicker, title):
    _text(slide, Inches(0.6), Inches(0.42), Inches(12), Inches(0.3),
          [(kicker.upper(), {"size": 12, "bold": True, "color": ACCENT})])
    _text(slide, Inches(0.6), Inches(0.72), Inches(12.1), Inches(0.7),
          [(title, {"font": HFONT, "size": 28, "bold": True, "color": INK})])


def _footer(slide, n):
    _text(slide, Inches(0.6), H - Inches(0.42), Inches(9), Inches(0.3),
          [("Crédit du Congo · Groupe Attijariwafa Bank   |   Confidentiel — agrégats uniquement",
            {"size": 9, "color": MUTE})])
    _text(slide, W - Inches(1.0), H - Inches(0.42), Inches(0.4), Inches(0.3),
          [(str(n), {"size": 9, "color": MUTE})], align=PP_ALIGN.RIGHT)


def _dark_bg(slide, color=INK):
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = color


def build_report(agg) -> BytesIO:
    prs = Presentation()
    prs.slide_width, prs.slide_height = W, H
    blank = prs.slide_layouts[6]
    carto = agg["carto"]
    prio = agg["priorities"]
    seg = agg["segments"]
    avg_gap = agg["avg_gap"]
    reduction = agg["reduction"]
    gap_after = round(avg_gap * (1 - reduction / 100), 2)
    page = 0

    # 1. Couverture
    s = prs.slides.add_slide(blank); _dark_bg(s)
    _text(s, Inches(0.6), Inches(2.0), Inches(10), Inches(0.4),
          [("RAPPORT EXÉCUTIF", {"size": 15, "bold": True, "color": ACCENT})])
    _text(s, Inches(0.6), Inches(2.45), Inches(11), Inches(1.6),
          [("Programme Cross-Mentoring Digital Banking", {"font": HFONT, "size": 40, "bold": True, "color": WHITE})])
    _text(s, Inches(0.6), Inches(4.35), Inches(9.6), Inches(0.7),
          [("Diagnostic 8 niveaux, mentorat et impact — synthèse pour le Comité de direction", {"size": 15, "color": ICE})])
    _text(s, Inches(0.6), Inches(6.5), Inches(11), Inches(0.4),
          [("Crédit du Congo · Groupe Attijariwafa Bank · Direction du Capital Humain · "
            + date.today().strftime("%d/%m/%Y"), {"size": 12, "color": RGBColor(0x8F, 0xA3, 0xBF)})])

    # 2. Synthèse exécutive
    s = prs.slides.add_slide(blank); page += 1
    _title(s, "Synthèse exécutive", "L'essentiel en un coup d'œil")
    cards = [(str(agg["participants"]), "Participants", INK, "échelle à 8 niveaux"),
             (f"{avg_gap:.1f}", "Écart moyen /8", GOLD, "niveau vs cible métier"),
             (f"−{reduction}%", "Réduction de l'écart", ACCENT, "projetée"),
             (f"{agg['mentors']}", "Mentors", ACCENT, "vivier disponible")]
    for i, (v, l, c, sub) in enumerate(cards):
        _stat(s, Inches(0.6 + i * 3.05), Inches(1.7), Inches(2.9), Inches(1.7), v, l, c, sub)
    _text(s, Inches(0.6), Inches(3.9), Inches(12.1), Inches(1.5),
          [("Lecture — ", {"bold": True, "color": INK, "size": 15}),
           (f"Les collaborateurs se situent à un écart moyen de {avg_gap:.1f} niveau sous la cible de leur métier. "
            f"Deux priorités se détachent : ", {"color": SLATE, "size": 15}),
           (f"{prio[0]['name']} et {prio[1]['name']}", {"bold": True, "color": INK, "size": 15}),
           (f". Le mentorat croisé vise une réduction de l'écart de {reduction}%, mesurée par la validation "
            "effective des compétences.", {"color": SLATE, "size": 15})], space=1.15)
    _card(s, Inches(0.6), Inches(5.5), Inches(12.1), Inches(1.15), fill=LIGHTBG, line=None)
    chips = [("PRIORITÉ 1", prio[0]["name"], RGBColor(0xDC, 0x26, 0x26)),
             ("PRIORITÉ 2", prio[1]["name"], GOLD),
             ("POINT FORT", prio[-1]["name"], ACCENT)]
    for i, (k, v, c) in enumerate(chips):
        x = Inches(0.95 + i * 3.95)
        _text(s, x, Inches(5.68), Inches(3.6), Inches(0.3), [(k, {"size": 11, "bold": True, "color": c})])
        _text(s, x, Inches(5.98), Inches(3.7), Inches(0.5), [(v, {"font": HFONT, "size": 16, "bold": True, "color": INK})])
    _footer(s, page)

    # 3. KPIs
    s = prs.slides.add_slide(blank); page += 1
    _title(s, "Pilotage", "Indicateurs clés du programme")
    kp = [(str(agg["participants"]), "Participants", INK, None),
          (f"{agg['mentors']}", "Mentors", ACCENT, "vivier"),
          (f"{avg_gap:.1f}", "Écart moyen /8", GOLD, "actuel"),
          (str(agg["binomes"]), "Binômes actifs", INK, "mentor/mentoré"),
          (f"{agg['diagnostics']}", "Diagnostics", ACCENT, "complétés"),
          (f"−{reduction}%", "Réduction visée", ACCENT, "de l'écart")]
    for i, (v, l, c, sub) in enumerate(kp):
        col, row = i % 3, i // 3
        _stat(s, Inches(0.6 + col * 4.05), Inches(1.75 + row * 2.15), Inches(3.85), Inches(1.85), v, l, c, sub)
    _footer(s, page)

    # 4. Cartographie (graphique natif)
    s = prs.slides.add_slide(blank); page += 1
    _title(s, "Diagnostic collectif", "Cartographie des compétences : actuel vs cible (/8)")
    cd = CategoryChartData()
    cd.categories = [c["id"] for c in carto]
    cd.add_series("Niveau actuel", tuple(c["avg"] for c in carto))
    cd.add_series("Cible métier", tuple(c["target"] for c in carto))
    gf = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.6), Inches(1.7), Inches(8.3), Inches(5.1), cd)
    ch = gf.chart
    ch.has_title = False
    ch.has_legend = True; ch.legend.position = XL_LEGEND_POSITION.TOP; ch.legend.include_in_layout = False
    ch.legend.font.size = Pt(11); ch.legend.font.name = BFONT
    ch.value_axis.minimum_scale = 0; ch.value_axis.maximum_scale = 8
    ch.value_axis.tick_labels.font.size = Pt(10); ch.value_axis.tick_labels.font.color.rgb = MUTE
    ch.category_axis.tick_labels.font.size = Pt(11); ch.category_axis.tick_labels.font.bold = True
    ch.category_axis.tick_labels.font.color.rgb = INK
    ch.series[0].format.fill.solid(); ch.series[0].format.fill.fore_color.rgb = ACCENT
    ch.series[1].format.fill.solid(); ch.series[1].format.fill.fore_color.rgb = LIGHT
    _card(s, Inches(9.2), Inches(1.7), Inches(3.55), Inches(5.1), fill=LIGHTBG, line=None)
    _text(s, Inches(9.45), Inches(1.95), Inches(3.1), Inches(0.4),
          [("Où se creusent les écarts ?", {"font": HFONT, "size": 15, "bold": True, "color": INK})])
    for i, p in enumerate(prio[:4]):
        y = Inches(2.55 + i * 1.02)
        _text(s, Inches(9.45), y, Inches(3.1), Inches(0.34), [(p["name"], {"size": 12, "bold": True, "color": INK})])
        _text(s, Inches(9.45), y + Inches(0.3), Inches(3.1), Inches(0.3),
              [(f"Écart {p['gap']:.1f}  ·  {p['avg']:.1f} → {p['target']:.1f}", {"size": 10.5, "color": MUTE})])
    _footer(s, page)

    # 5. Populations (graphique barres)
    s = prs.slides.add_slide(blank); page += 1
    _title(s, "Ciblage", "Populations à accompagner en priorité")
    cd2 = CategoryChartData()
    cd2.categories = [x["entite"] for x in seg]
    cd2.add_series("Écart moyen", tuple(x["avg_gap"] for x in seg))
    gf2 = s.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(0.6), Inches(1.8), Inches(8.2), Inches(5.0), cd2)
    ch2 = gf2.chart
    ch2.has_title = False; ch2.has_legend = False
    ch2.value_axis.minimum_scale = 0
    ch2.value_axis.tick_labels.font.size = Pt(10); ch2.value_axis.tick_labels.font.color.rgb = MUTE
    ch2.category_axis.tick_labels.font.size = Pt(11); ch2.category_axis.tick_labels.font.color.rgb = INK
    ch2.series[0].format.fill.solid(); ch2.series[0].format.fill.fore_color.rgb = INK2
    _card(s, Inches(9.1), Inches(1.8), Inches(3.65), Inches(5.0), fill=LIGHTBG, line=None)
    _text(s, Inches(9.35), Inches(2.05), Inches(3.2), Inches(0.35),
          [("Lecture", {"font": HFONT, "size": 15, "bold": True, "color": INK})])
    top = seg[0]
    _text(s, Inches(9.35), Inches(2.5), Inches(3.2), Inches(1.8),
          [(f"{top['entite']} ", {"bold": True, "color": INK, "size": 12.5}),
           (f"présente l'écart moyen le plus élevé ({top['avg_gap']:.2f}) et concentre l'effort de mentorat "
            "en début de programme.", {"color": SLATE, "size": 12.5})], space=1.15)
    _text(s, Inches(9.35), Inches(4.6), Inches(3.2), Inches(1.8),
          [("Affectation priorisée sur ces entités, dans le respect du seuil d'anonymisation (n ≥ 5).",
            {"color": MUTE, "size": 11.5, "italic": True})], space=1.15)
    _footer(s, page)

    # 6. Impact (sombre)
    s = prs.slides.add_slide(blank); page += 1; _dark_bg(s)
    _text(s, Inches(0.6), Inches(0.55), Inches(12), Inches(0.35), [("IMPACT", {"size": 13, "bold": True, "color": ACCENT})])
    _text(s, Inches(0.6), Inches(0.9), Inches(12), Inches(0.7),
          [("Réduction de l'écart de compétence", {"font": HFONT, "size": 28, "bold": True, "color": WHITE})])
    _text(s, Inches(1.4), Inches(2.4), Inches(3), Inches(0.35),
          [("AVANT", {"size": 13, "bold": True, "color": RGBColor(0x8F, 0xA3, 0xBF)})], align=PP_ALIGN.CENTER)
    _text(s, Inches(1.4), Inches(2.75), Inches(3), Inches(1.5),
          [(f"{avg_gap:.1f}", {"font": HFONT, "size": 80, "bold": True, "color": ICE})], align=PP_ALIGN.CENTER)
    ar = s.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, Inches(5.0), Inches(3.15), Inches(3.3), Inches(0.8))
    ar.fill.solid(); ar.fill.fore_color.rgb = ACCENT; ar.line.fill.background(); ar.shadow.inherit = False
    _text(s, Inches(5.0), Inches(2.5), Inches(3.3), Inches(0.5),
          [(f"−{reduction}%", {"font": HFONT, "size": 22, "bold": True, "color": ACCENT})], align=PP_ALIGN.CENTER)
    _text(s, Inches(8.7), Inches(2.4), Inches(3.5), Inches(0.35),
          [("APRÈS (projeté)", {"size": 13, "bold": True, "color": RGBColor(0x8F, 0xA3, 0xBF)})], align=PP_ALIGN.CENTER)
    _text(s, Inches(8.9), Inches(2.75), Inches(3), Inches(1.5),
          [(f"{gap_after:.1f}", {"font": HFONT, "size": 80, "bold": True, "color": WHITE})], align=PP_ALIGN.CENTER)
    _text(s, Inches(1.4), Inches(5.4), Inches(10.5), Inches(1.0),
          [("Le Skill Gap Reduction est l'indicateur central présenté au Comité de direction. La valeur projetée "
            "sera confirmée après le pilote, en mesure pré / post avec cohorte de comparaison.",
            {"size": 13, "color": ICE})], align=PP_ALIGN.CENTER, space=1.2)

    # 7. Confidentialité
    s = prs.slides.add_slide(blank); page += 1
    _title(s, "Gouvernance", "Confidentialité by design")
    _card(s, Inches(0.6), Inches(1.8), Inches(12.1), Inches(1.5), fill=RGBColor(0xE6, 0xF4, 0xF0), line=None)
    _text(s, Inches(0.9), Inches(2.0), Inches(11.5), Inches(1.1),
          [("Le score de compétence est isolé des décisions RH. ", {"bold": True, "color": INK, "size": 14.5}),
           ("Ce rapport ne présente que des agrégats ; aucun score individuel n'y figure. Le verrou est appliqué "
            "côté serveur : toute demande de score individuel par un profil RH est refusée, et aucun agrégat "
            "n'est communiqué sous le seuil d'anonymisation.", {"color": SLATE, "size": 14.5})],
          anchor=MSO_ANCHOR.MIDDLE, space=1.15)
    guards = [("Seuil d'anonymisation", "Aucun agrégat sous n ≥ 5 collaborateurs."),
              ("Séparation des données", "Notes de séance et aveux cloisonnés du pilotage."),
              ("Non-usage RH garanti", "Le serveur interdit l'export du score vers la RH."),
              ("Scoring autoritatif", "Les 8 niveaux sont calculés côté serveur.")]
    for i, (t, d) in enumerate(guards):
        col, row = i % 2, i // 2
        x, y = Inches(0.6 + col * 6.15), Inches(3.7 + row * 1.5)
        dot = s.shapes.add_shape(MSO_SHAPE.OVAL, x, y, Inches(0.34), Inches(0.34))
        dot.fill.solid(); dot.fill.fore_color.rgb = ACCENT; dot.line.fill.background(); dot.shadow.inherit = False
        _text(s, x, y, Inches(0.34), Inches(0.34), [("✓", {"size": 13, "bold": True, "color": WHITE})],
              align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
        _text(s, x + Inches(0.5), y - Inches(0.02), Inches(5.5), Inches(0.4), [(t, {"size": 14, "bold": True, "color": INK})])
        _text(s, x + Inches(0.5), y + Inches(0.34), Inches(5.4), Inches(0.8), [(d, {"size": 12, "color": SLATE})], space=1.1)
    _footer(s, page)

    # 8. Clôture (sombre)
    s = prs.slides.add_slide(blank); _dark_bg(s)
    _text(s, Inches(0.6), Inches(2.4), Inches(12), Inches(0.4),
          [("PROCHAINES ÉTAPES", {"size": 14, "bold": True, "color": ACCENT})])
    _text(s, Inches(0.6), Inches(2.85), Inches(11.5), Inches(1.0),
          [("Lancer le pilote, mesurer, généraliser", {"font": HFONT, "size": 32, "bold": True, "color": WHITE})])
    _text(s, Inches(0.6), Inches(4.1), Inches(11.5), Inches(1.4),
          [("1.  Valider priorités et vivier de mentors en Comité.\n", {"color": ICE, "size": 15}),
           ("2.  Lancer le pilote sur les entités les plus en écart.\n", {"color": ICE, "size": 15}),
           ("3.  Mesurer en pré / post, puis généraliser.", {"color": ICE, "size": 15})], space=1.35)
    _text(s, Inches(0.6), Inches(6.6), Inches(12), Inches(0.4),
          [("Direction du Capital Humain · Crédit du Congo · Groupe Attijariwafa Bank",
            {"size": 12, "color": RGBColor(0x8F, 0xA3, 0xBF)})])

    buf = BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf
