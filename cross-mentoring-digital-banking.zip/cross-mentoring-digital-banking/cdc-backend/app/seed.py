"""Peuplement initial (démo). Idempotent : ne fait rien si des users existent."""
from sqlalchemy.orm import Session
from .models import User, CompetencyScore, MentoringPair, Certification
from .security import hash_password
from . import engine


def _add_user(db, uid, name, email, role, metier, entite, levels=None, dispo=None, interests=None):
    u = User(id=uid, email=email, hashed_password=hash_password("demo1234"), full_name=name,
             role=role, metier=metier, entite=entite, dispo=dispo or ["mar", "jeu"],
             interests=interests or [], diagnostic_done=bool(levels),
             parcours=(45 if role == "mentee" and levels else 0))
    db.add(u)
    if levels:
        for f in engine.FAMILIES:
            lvl = levels.get(f, 3)
            db.add(CompetencyScore(user_id=uid, family=f, level=lvl, score=(lvl / engine.NLEV * 100)))
    return u


def seed(db: Session):
    if db.query(User).count() > 0:
        return
    _add_user(db, "u1", "Sophie Milandou", "sophie@cdc.cg", "mentee", "Conseiller clientèle", "Agence Centre",
              {"CUL": 3, "COL": 5, "DAT": 3, "CLI": 5, "CYB": 6, "IA": 2, "DBK": 2, "PRO": 3})
    _add_user(db, "u2", "Jean Bakala", "jean@cdc.cg", "mentee", "Chargé d'affaires", "Entreprises",
              {"CUL": 4, "COL": 3, "DAT": 3, "CLI": 5, "CYB": 4, "IA": 3, "DBK": 3, "PRO": 3}, ["lun", "mer"])
    _add_user(db, "u3", "Grace Nkodia", "grace@cdc.cg", "mentee", "Analyste risques", "Risques",
              {"CUL": 4, "COL": 4, "DAT": 5, "CLI": 3, "CYB": 5, "IA": 3, "DBK": 3, "PRO": 3})
    _add_user(db, "u4", "Patrick Loemba", "patrick@cdc.cg", "mentee", "Contrôleur de gestion", "Finance",
              {"CUL": 3, "COL": 4, "DAT": 5, "CLI": 3, "CYB": 4, "IA": 3, "DBK": 3, "PRO": 4})
    _add_user(db, "u5", "Estelle Goma", "estelle@cdc.cg", "mentee", "Chargé marketing", "Marketing",
              {"CUL": 4, "COL": 4, "DAT": 3, "CLI": 5, "CYB": 3, "IA": 3, "DBK": 4, "PRO": 3}, ["jeu"])
    _add_user(db, "u6", "Alain Massamba", "alain@cdc.cg", "mentee", "Chargé conformité", "Conformité",
              {"CUL": 3, "COL": 3, "DAT": 3, "CLI": 3, "CYB": 6, "IA": 2, "DBK": 3, "PRO": 4})
    _add_user(db, "m1", "Nadia Ilende", "nadia@cdc.cg", "mentor", "Data analyst", "Data & BI",
              {"CUL": 6, "COL": 6, "DAT": 8, "CLI": 5, "CYB": 6, "IA": 7, "DBK": 7, "PRO": 7}, interests=["DAT", "IA", "DBK"])
    _add_user(db, "m2", "Yannick Mabiala", "yannick@cdc.cg", "mentor", "Manager agence", "Réseau",
              {"CUL": 6, "COL": 6, "DAT": 5, "CLI": 8, "CYB": 5, "IA": 5, "DBK": 7, "PRO": 6}, interests=["CLI", "DBK", "PRO"])
    _add_user(db, "m3", "Prisca Ndinga", "prisca@cdc.cg", "mentor", "Chargé conformité", "Cyber & Conformité",
              {"CUL": 5, "COL": 5, "DAT": 5, "CLI": 3, "CYB": 8, "IA": 4, "DBK": 5, "PRO": 7}, ["lun", "mer", "ven"], ["CYB", "PRO"])
    _add_user(db, "rh1", "Direction Capital Humain", "rh@cdc.cg", "rh", "RH", "DCH")

    db.add(MentoringPair(mentor_id="m2", mentee_id="u1", status="active"))
    db.add(MentoringPair(mentor_id="m1", mentee_id="u3", status="active"))
    db.add(MentoringPair(mentor_id="m3", mentee_id="u6", status="active"))
    for uid in ("u1", "u3", "u6"):
        db.add(Certification(user_id=uid, family="CYB", level=6, badge="Explorer"))
    db.commit()
