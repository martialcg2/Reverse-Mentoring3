"""
Schémas Pydantic.
Point clé du firewall : il existe DEUX familles de schémas de sortie pour un
participant. Le schéma de périmètre RH (ParticipantAdminOut) N'A PAS de champ
de score/niveau — il est structurellement impossible d'y faire fuiter un score.
Les scores ne vivent que dans CompetencyOut, servi uniquement au sujet lui-même
et à son mentor.
"""
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict


# ---------- Auth ----------
class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: str
    full_name: str


# ---------- Vue ADMIN / RH (aucun score) ----------
class ParticipantAdminOut(BaseModel):
    id: str
    full_name: str
    role: str
    metier: str
    entite: str
    dispo: List[str] = []
    diagnostic_done: bool = False
    parcours: int = 0
    mentor_id: Optional[str] = None       # binôme (administratif)

    class Config:
        from_attributes = True


class ParticipantCreate(BaseModel):
    full_name: str
    email: EmailStr
    password: str = "changeme"
    role: str = "mentee"                  # mentee | mentor
    metier: str = "Conseiller clientèle"
    entite: str = "—"
    dispo: List[str] = []
    interests: List[str] = []


class ParticipantUpdate(BaseModel):
    full_name: Optional[str] = None
    role: Optional[str] = None
    metier: Optional[str] = None
    entite: Optional[str] = None
    dispo: Optional[List[str]] = None
    interests: Optional[List[str]] = None
    mentor_id: Optional[str] = None       # affectation de binôme


# ---------- Vue SENSIBLE (sujet + son mentor uniquement) ----------
class CompetencyOut(BaseModel):
    family: str
    name: str
    level: int
    target: int
    gap: int
    score: Optional[float] = None         # démontré 0-100


class ProfileScoresOut(BaseModel):
    user_id: str
    full_name: str
    metier: str
    global_score: int
    mean_level: float
    competencies: List[CompetencyOut]


# ---------- Diagnostic ----------
class DiagnosticSubmit(BaseModel):
    # answers[famille] = {"Fondamental": 0-100, "Opérationnel": 0-100, "Expertise": 0-100}
    answers: Dict[str, Dict[str, float]]
    declared: Dict[str, int] = {}
    dont_know: int = 0


# ---------- Matching (périmètre RH : jamais de score brut) ----------
class MatchProposalOut(BaseModel):
    mentee_id: str
    mentee_name: str
    mentor_id: str
    mentor_name: str
    compatibility: int
    covered: int
    n_prio: int


class MatchValidateIn(BaseModel):
    mentee_id: str
    mentor_id: str


# ---------- Séance ----------
class SessionCreate(BaseModel):
    mentee_id: str
    family: str
    notes: str = ""
    duration_min: int = 45


# ---------- Reporting RH (agrégats seulement) ----------
class CartoRow(BaseModel):
    id: str
    name: str
    avg: float
    target: float
    gap: float


class TrackingRow(BaseModel):
    """Statut par participant — SANS score (firewall)."""
    id: str
    full_name: str
    metier: str
    entite: str
    mentor_name: Optional[str]
    diagnostic_done: bool
    parcours: int
    badges: int
