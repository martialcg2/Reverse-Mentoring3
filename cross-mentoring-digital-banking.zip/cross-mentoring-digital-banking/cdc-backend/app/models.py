"""
Modèle de données (cahier des charges §27).
Les données SENSIBLES (scores individuels, notes de séance) sont isolées dans
des tables dédiées ; le firewall (app/firewall.py) garantit qu'aucune route de
périmètre RH ne les sérialise jamais.
"""
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from .database import Base


def _id() -> str:
    return uuid.uuid4().hex[:12]


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=_id)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, nullable=False, default="mentee")   # mentee | mentor | rh | admin
    metier = Column(String, default="Conseiller clientèle")
    entite = Column(String, default="—")
    langue = Column(String, default="FR")
    dispo = Column(JSON, default=list)         # ["mar","jeu"]
    interests = Column(JSON, default=list)      # familles d'expertise mentor
    diagnostic_done = Column(Boolean, default=False)
    parcours = Column(Integer, default=0)       # % d'avancement (statut, non sensible)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class CompetencyScore(Base):
    """SENSIBLE — niveau et score démontré par famille. Jamais exposé à la RH."""
    __tablename__ = "competency_scores"
    id = Column(String, primary_key=True, default=_id)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    family = Column(String, nullable=False)     # CUL..PRO
    level = Column(Integer, default=1)           # 1..8
    score = Column(Float, default=0.0)           # 0..100 démontré
    declared = Column(Integer, default=0)        # auto-évaluation 1..8 (confidentiel)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Assessment(Base):
    """SENSIBLE — trace d'un diagnostic (dimensions, fiabilité)."""
    __tablename__ = "assessments"
    id = Column(String, primary_key=True, default=_id)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    global_score = Column(Integer, default=0)
    dims = Column(JSON, default=dict)
    low_conf = Column(JSON, default=list)
    dont_know = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class MentoringPair(Base):
    __tablename__ = "mentoring_pairs"
    id = Column(String, primary_key=True, default=_id)
    mentor_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    mentee_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    status = Column(String, default="active")   # proposed | active | closed
    compatibility = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class MentoringSession(Base):
    """La colonne notes est CONFIDENTIELLE (binôme uniquement)."""
    __tablename__ = "mentoring_sessions"
    id = Column(String, primary_key=True, default=_id)
    pair_id = Column(String, ForeignKey("mentoring_pairs.id"), index=True, nullable=False)
    family = Column(String)
    level_before = Column(Integer)
    level_after = Column(Integer)
    duration_min = Column(Integer, default=45)
    notes = Column(Text, default="")            # CONFIDENTIEL
    created_at = Column(DateTime, default=datetime.utcnow)


class Certification(Base):
    """Badges / certifications — visibles par la RH (firewall §21)."""
    __tablename__ = "certifications"
    id = Column(String, primary_key=True, default=_id)
    user_id = Column(String, ForeignKey("users.id"), index=True, nullable=False)
    family = Column(String)
    level = Column(Integer)
    badge = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
