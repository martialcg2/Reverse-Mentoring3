# Cross-Mentoring Digital Banking

Plateforme de mentorat croisé pour le développement des compétences digitales — **Crédit du Congo · Groupe Attijariwafa Bank**.

Ce dépôt contient l'application complète :

```
.
├── cdc-backend/        API FastAPI + PostgreSQL (firewall de confidentialité côté serveur, PPTX)
├── cdc-frontend/       Interface React (Vite) — connexion, 3 espaces, données serveur
├── docker-compose.yml  Pile complète en une commande (db + api + web)
├── render.yaml         Déploiement de l'API sur Render (monorepo)
└── README.md           Ce guide
```

Deux façons de déployer, au choix :
- **A. En local, tout-en-un** avec Docker (une commande).
- **B. Dans le cloud, gratuitement** : Neon (base) + Render (API) + Vercel (interface).

Comptes de démonstration (mot de passe `demo1234`) : `rh@cdc.cg` · `nadia@cdc.cg` (mentor) · `sophie@cdc.cg` (mentorée).

---

## Étape 1 — Mettre le code sur GitHub

Décompressez ce dossier, puis dans un terminal à sa racine :

```bash
git init
git add .
git commit -m "Cross-Mentoring Digital Banking — version initiale"
```

Créez un dépôt **vide** sur github.com (bouton *New repository*, sans README ni .gitignore), puis :

```bash
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/cross-mentoring.git
git push -u origin main
```

Le code est maintenant sur GitHub. Rien de sensible n'est poussé (`.gitignore` exclut `node_modules`, bases, `.env`).

---

## Étape 2 — Option A : lancer en local avec Docker

Prérequis : Docker Desktop installé.

```bash
docker compose up --build
```

- Interface : **http://localhost:8080**
- API + documentation : **http://localhost:8000/docs**

Pour arrêter : `docker compose down` (ajoutez `-v` pour effacer la base).

---

## Étape 3 — Option B : déploiement cloud gratuit

### 3.1 — Base de données (Neon)

1. Créez un compte sur **[neon.tech](https://neon.tech)** et un projet PostgreSQL (offre gratuite).
2. Copiez la chaîne de connexion (elle ressemble à `postgresql://user:pass@ep-xxx.neon.tech/cdc?sslmode=require`).

### 3.2 — API (Render)

1. Sur **[render.com](https://render.com)** : *New +* → *Blueprint* → sélectionnez votre dépôt GitHub.
2. Render détecte `render.yaml` (l'API est dans `cdc-backend`, géré par `rootDir`).
3. Renseignez les variables demandées :
   - `DATABASE_URL` = la chaîne Neon de l'étape 3.1
   - `CORS_ORIGINS` = laissez vide pour l'instant (on la remplira à l'étape 3.4)
   - `SECRET_KEY` = générée automatiquement
4. Déployez. Une fois en ligne, vérifiez `https://VOTRE-API.onrender.com/health` → `{"status":"ok"}`.
5. Notez l'URL de l'API.

### 3.3 — Interface (Vercel)

1. Sur **[vercel.com](https://vercel.com)** : *Add New* → *Project* → importez le même dépôt.
2. **Root Directory** : `cdc-frontend`. Framework détecté : *Vite*.
3. Variable d'environnement : `VITE_API_URL` = l'URL de l'API (étape 3.2), **sans slash final**.
4. Déployez. Notez l'URL de l'interface (ex. `https://cross-mentoring.vercel.app`).

### 3.4 — Relier les deux (CORS)

Retournez sur Render → votre service `cross-mentoring-api` → *Environment* :
- `CORS_ORIGINS` = l'URL Vercel de l'étape 3.3 (ex. `https://cross-mentoring.vercel.app`).

Render redéploie automatiquement. Ouvrez l'URL Vercel : l'interface parle à l'API. ✅

---

## Vérifier que tout fonctionne

1. Connectez-vous en **RH** (`rh@cdc.cg`) → onglet *Rapports* → **Générer le PPT exécutif** : un `.pptx` se télécharge.
2. Connectez-vous en **mentorée** (`sophie@cdc.cg`) → *Diagnostic* : le score est recalculé côté serveur.
3. Preuve du firewall : la RH ne peut obtenir aucun score individuel (le serveur répond `403`).

---

## Personnalisation

| Variable | Où | Rôle |
|---|---|---|
| `DATABASE_URL` | API | Connexion PostgreSQL |
| `SECRET_KEY` | API | Clé de signature JWT |
| `CORS_ORIGINS` | API | Origine(s) autorisée(s) du frontend |
| `SEED_ON_STARTUP` | API | Insère les données de démo au 1er démarrage |
| `VITE_API_URL` | Frontend (build) | URL de l'API appelée par le navigateur |

---

## Passage en production (au-delà du pilote)

- **Authentification** : remplacer le login local par le **SSO d'entreprise + MFA** (le modèle de rôles ne change pas).
- **Schéma** : gérer les migrations avec **Alembic** (le projet crée les tables au démarrage pour la démo).
- **Souveraineté** : l'hébergement gratuit est hors entreprise ; pour la donnée bancaire réelle, revalider la localisation avec la Conformité (droit congolais, COBAC/CEMAC, politiques Groupe).

Détails techniques : `cdc-backend/README.md` et `cdc-frontend/README.md`.
